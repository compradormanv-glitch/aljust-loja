# Al.just — Loja Online

## Como abrir
Abra o arquivo `index.html` no Chrome, Edge ou outro navegador.

## Antes de publicar
1. Abra `script.js`.
2. Troque `2449XXXXXXXX` pelo número real do WhatsApp da Al.just.
3. Edite a lista `products` com os seus produtos, preços e categorias.
4. Troque os links de Instagram/Facebook/TikTok no `index.html`.
5. Substitua `info@aljust.ao` pelo e-mail real, se necessário.

## Publicação
Pode enviar os três ficheiros/pasta para um serviço de hospedagem estática ou para uma hospedagem com domínio próprio.

## Observação
Esta primeira versão é uma loja front-end. O carrinho funciona no navegador e o fechamento do pedido é feito via WhatsApp. Para pagamentos online, estoque centralizado, área de cliente e painel administrativo, será necessário adicionar um backend/serviço de e-commerce.
